// =========================================================
//                  1. الإعدادات والتهيئة
// =========================================================

import { initializeApp } from 'https://www.gstatic.com/firebasejs/9.6.1/firebase-app.js';
import { getFirestore, doc, setDoc, getDoc, collection, query, where, updateDoc, arrayUnion, getDocs, deleteDoc, runTransaction } from 'https://www.gstatic.com/firebasejs/9.6.1/firebase-firestore.js';
import { getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut } from 'https://www.gstatic.com/firebasejs/9.6.1/firebase-auth.js';

// *******************************************************************
// ⚠️ استبدل هذه الإعدادات بمعلومات مشروعك الحقيقية ⚠️
// *******************************************************************
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "SENDER_ID",
  appId: "APP_ID"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

// ---------- الثوابت ----------
const ADMIN_USERNAME = "admin";
const ADMIN_PASSWORD = "987456123@";
const WHATSAPP_NUMBER = "201113318419";
const WHATSAPP_CHARGE_LINK = `https://wa.me/${WHATSAPP_NUMBER}?text=%D8%B4%D8%AD%D9%86%20%D8%AD%D8%B3%D8%A7%D8%A8%D9%8A`;
const TELEGRAM_LINK = "https://t.me/Alpo_Tik";

function getCurrentUserId() {
    return localStorage.getItem("loggedUser");
}

// =========================================================
//        2. المصادقة والتحكم في الواجهة
// =========================================================

function goToChargeAccount(){
    window.open(WHATSAPP_CHARGE_LINK, '_blank');
}
function goToTelegram(){
    window.open(TELEGRAM_LINK, '_blank');
}
function showSignup(){
    document.getElementById("loginSection")?.classList.add("hidden");
    document.getElementById("signupSection")?.classList.remove("hidden");
}
function showLogin(){
    document.getElementById("signupSection")?.classList.add("hidden");
    document.getElementById("loginSection")?.classList.remove("hidden");
}

async function signup(){
    const user = document.getElementById("signupUser")?.value.trim();
    const pass = document.getElementById("signupPass")?.value.trim();
    const phone = document.getElementById("signupPhone")?.value.trim();
    const email = document.getElementById("signupEmail")?.value.trim();

    if(!user || !pass || !phone || !email) return alert("املأ كل الخانات!");
    if(!/@gmail\.com$/.test(email)) return alert("البريد يجب أن يكون gmail.com فقط!");

    try {
        const userCredential = await createUserWithEmailAndPassword(auth, email, pass);
        const userId = userCredential.user.uid;

        const userDocRef = doc(db, "users", userId);
        await setDoc(userDocRef, {
            username: user,
            phone: phone,
            email: email,
            balance: 0,
            customData: {}, 
            history: []     
        });

        alert("✅ تم إنشاء الحساب بنجاح!");
        showLogin();
    } catch (error) {
        alert(`❌ خطأ في إنشاء الحساب: ${error.message}`);
    }
}

async function login(){
    const loginValue = document.getElementById("loginUser")?.value.trim();
    const pass = document.getElementById("loginPass")?.value.trim();

    if(loginValue === ADMIN_USERNAME && pass === ADMIN_PASSWORD){
        localStorage.setItem("loggedUser", "admin");
        openAdmin();
        return;
    }

    try {
        const userCredential = await signInWithEmailAndPassword(auth, loginValue, pass);
        const userId = userCredential.user.uid;

        localStorage.setItem("loggedUser", userId); 
        alert("✅ تم تسجيل الدخول بنجاح!");
        openHome();
    } catch (error) {
        alert("❌ فشل تسجيل الدخول. تأكد من الإيميل وكلمة المرور.");
    }
}

async function loadUserData(userId){
    try {
        const userDocRef = doc(db, "users", userId);
        const docSnap = await getDoc(userDocRef);

        if (docSnap.exists()) {
            const data = docSnap.data();
            document.getElementById("usernameDisplay").textContent = data.username || "مستخدم";
            document.getElementById("userBalanceDisplay").textContent = Number(data.balance).toFixed(2);
            return data;
        } else {
            console.error("بيانات المستخدم غير موجودة!");
            logout();
        }
    } catch (error) {
        console.error("خطأ في جلب بيانات المستخدم:", error);
    }
}

function openHome(){
    const userId = getCurrentUserId();
    if (!userId || userId === "admin") {
        showLogin();
        return;
    }
    
    document.getElementById("loginSection")?.classList.add("hidden");
    document.getElementById("signupSection")?.classList.add("hidden");
    document.getElementById("adminPanel")?.classList.add("hidden");
    document.getElementById("userHistoryView")?.classList.add("hidden");
    document.getElementById("userHome")?.classList.remove("hidden");

    loadUserData(userId);
    loadCategoriesForUser(); // الآن تم ربطها
    document.getElementById("itemSearchResult").innerHTML = "";
}

function logout(){
    signOut(auth).then(() => {
        localStorage.removeItem("loggedUser");
        document.getElementById("userHome")?.classList.add("hidden");
        document.getElementById("adminPanel")?.classList.add("hidden");
        document.getElementById("userHistoryView")?.classList.add("hidden");
        document.getElementById("loginSection")?.classList.remove("hidden");
    }).catch((error) => {
        console.error("خطأ في تسجيل الخروج:", error);
    });
}

// =========================================================
//       3. سجل المستخدم (محدثة لـ Firebase)
// =========================================================

async function showUserHistory() {
    const userId = getCurrentUserId();
    if (!userId) return showLogin();

    document.getElementById("userHome")?.classList.add("hidden");
    document.getElementById("userHistoryView")?.classList.remove("hidden");
    
    const userData = await loadUserData(userId);
    const history = userData?.history || [];
    const historyListDiv = document.getElementById("userHistoryList");
    historyListDiv.innerHTML = "";

    if (history.length === 0) {
        historyListDiv.innerHTML = "<p>لا يوجد سجل شراء لديك حالياً.</p>";
        return;
    }
    
    // عرض السجل الأحدث أولاً
    history.slice().reverse().forEach((log) => {
        const logItem = document.createElement("div");
        logItem.className = "log-item";
        logItem.innerHTML = `
            <p><strong>الطلب:</strong> ${log.itemName} (ID: ${log.id})</p>
            <p><strong>المبلغ المدفوع:</strong> ${Number(log.price).toFixed(2)} جنيه</p>
            <p><strong>التاريخ:</strong> ${new Date(log.timestamp).toLocaleString('ar-EG')}</p>
            <p><strong>حالة الطلب:</strong> **${log.status}**</p>
        `;
        historyListDiv.appendChild(logItem);
    });
}

// =========================================================
//        4. إدارة الأقسام والسلع (محدثة لـ Firebase)
// =========================================================

// دالة مساعدة: لجلب جميع الأقسام من Firestore
async function getCategoriesFromFirestore() {
    const catsRef = doc(db, "settings", "categories");
    const docSnap = await getDoc(catsRef);
    return docSnap.exists() ? docSnap.data().data : [];
}

// تحديث الأقسام في Firestore
async function updateCategoriesInFirestore(cats) {
    const catsRef = doc(db, "settings", "categories");
    await setDoc(catsRef, { data: cats });
}


// دوال عرض الأقسام للمستخدم (محدثة لـ Firestore)
async function loadCategoriesForUser(){
    const cats = await getCategoriesFromFirestore();
    const container = document.getElementById("userCategories");
    container.innerHTML = "";
    if(cats.length === 0){
        container.innerHTML = "<p>لا توجد أقسام حالياً.</p>";
        return;
    }
    cats.forEach((cat, index)=>{
        const btn = document.createElement("button");
        btn.textContent = cat.name;
        btn.onclick = ()=>showSubCategories(cats, index); 
        container.appendChild(btn);
    });
}
// تعديل الدوال التالية لتحمل الأقسام من ذاكرة المتصفح وليس السحابة مباشرة
function showSubCategories(cats, mainIndex, parentSubIndex = null){
    // ... (من الآن تستخدم المصفوفة cats التي تم جلبها)
    const mainCat = cats[mainIndex];
    const subDiv = document.getElementById("userSubCategories");
    const itemsDiv = document.getElementById("userItems");
    itemsDiv.innerHTML = "";
    
    let currentLevel = mainCat.subs;
    let categoryPath = mainCat.name;
    if (parentSubIndex !== null) {
        currentLevel = mainCat.subs[parentSubIndex].subs || [];
        categoryPath += ` / ${mainCat.subs[parentSubIndex].name}`;
    }
    
    subDiv.innerHTML = `<h3>الأقسام الفرعية لـ ${categoryPath}</h3>`;
    if(currentLevel.length === 0){
        subDiv.innerHTML += "<p>لا توجد أقسام فرعية.</p>";
        return;
    }
    currentLevel.forEach((sub, index)=>{
        const btn = document.createElement("button");
        btn.textContent = sub.name;
        
        if(sub.subs && sub.subs.length > 0){
            btn.onclick = ()=> parentSubIndex === null ? showSubCategories(cats, mainIndex, index) : showItems(sub);
        } else {
            btn.onclick = ()=>showItems(sub);
        }
        subDiv.appendChild(btn);
    });
}
function showItems(subCat){
    // ... (تستخدم بيانات subCat المحملة مسبقًا)
    const itemsDiv = document.getElementById("userItems");
    itemsDiv.innerHTML = `<h3>سلع قسم ${subCat.name}</h3>`;
    if(!subCat.items || subCat.items.length === 0){
        itemsDiv.innerHTML += "<p>لا توجد سلع هنا حالياً.</p>";
        return;
    }
    subCat.items.forEach(item=>{
        const card = document.createElement("div");
        card.className = "card";
        card.innerHTML = `
            <img src="${item.image || 'https://via.placeholder.com/150'}">
            <h3>${item.name}</h3>
            <p>كود الخدمة (ID): ${item.id}</p>
            <p>السعر: ${Number(item.price).toFixed(2)} جنيه</p> 
            <button class="buy-now-btn" onclick="buyNow('${item.name}','${item.id}', ${item.price}, '${item.orderField}')">شراء الآن 🛒</button>
        `;
        itemsDiv.appendChild(card);
    });
}
// دالة البحث (يجب تعديلها لتستخدم getCategoriesFromFirestore)
async function searchItemByID(){
    const searchID = document.getElementById("searchItemInput")?.value.trim();
    const resultDiv = document.getElementById("itemSearchResult");
    resultDiv.innerHTML = "<h3>نتائج البحث:</h3>";
    if (!searchID) return;

    const cats = await getCategoriesFromFirestore();
    let foundItem = null;
    
    function findItem(categories) {
        // ... (منطق البحث القديم)
    }
    foundItem = findItem(cats);

    // ... (عرض النتائج كما كان)
}

// ... دوال إدارة الأقسام للمشرف يجب تحديثها لاستخدام updateCategoriesInFirestore بعد كل تعديل ...


// =========================================================
//        5. لوحة المشرف (محدثة بالكامل لـ Firebase)
// =========================================================

function openAdmin(){
    document.getElementById("loginSection")?.classList.add("hidden");
    document.getElementById("signupSection")?.classList.add("hidden");
    document.getElementById("userHome")?.classList.add("hidden");
    document.getElementById("adminPanel")?.classList.remove("hidden");
    loadUsersList();
    loadPendingOrders(); // تم ربطها
    // loadAdminLog(); // تم ربطها
    // loadCategoriesAdmin(); // تحتاج لتحديث دوال التعديل
}

// ... (loadUsersList, editUser, deleteUser كما في الرد السابق) ...

// دالة تحميل وعرض الإشعارات المعلقة (محدثة لـ Firebase)
async function loadPendingOrders() {
    const pendingListDiv = document.getElementById("pendingOrdersList");
    const pendingOrdersRef = collection(db, "pendingOrders");
    
    try {
        const snapshot = await getDocs(query(pendingOrdersRef));
        const pendingOrders = snapshot.docs.map(doc => doc.data());

        pendingListDiv.innerHTML = "";
        document.getElementById("pendingCount").textContent = `(${pendingOrders.length} طلب)`;

        if (pendingOrders.length === 0) {
            pendingListDiv.innerHTML = "<p>🎉 لا توجد إشعارات شراء جديدة.</p>";
            return;
        }
        
        // ... (منطق عرض الطلبات في الواجهة) ...
    } catch (error) {
        console.error("خطأ في جلب الإشعارات:", error);
    }
}

// دالة الموافقة: نقل السجل من الإشعارات إلى السجل الدائم (محدثة لـ Firebase - باستخدام Transaction)
async function approveOrder(orderId) {
    const orderDocRef = doc(db, "pendingOrders", orderId.toString());
    const adminLogDocRef = doc(db, "adminLog", orderId.toString());

    try {
        await runTransaction(db, async (transaction) => {
            const orderDoc = await transaction.get(orderDocRef);
            if (!orderDoc.exists()) throw "الطلب غير موجود.";

            const approvedOrder = orderDoc.data();
            const userDocRef = doc(db, "users", approvedOrder.userId);
            const userDoc = await transaction.get(userDocRef);

            // 1. تحديث سجل المستخدم ليصبح "تمت الموافقة"
            const updatedHistory = userDoc.data().history.map(h => {
                if (h.id === orderId) {
                    return { ...h, status: "تمت الموافقة والتنفيذ" };
                }
                return h;
            });

            // 2. إضافة الطلب إلى السجل الدائم
            transaction.set(adminLogDocRef, {...approvedOrder, status: "تم التنفيذ والموافقة"});
            
            // 3. تحديث سجل المستخدم
            transaction.update(userDocRef, { history: updatedHistory });
            
            // 4. حذف الطلب من الإشعارات
            transaction.delete(orderDocRef);
        });

        alert("✅ تمت الموافقة بنجاح!");
        loadPendingOrders(); 
        // loadAdminLog(); // يجب تنفيذها
        
    } catch (error) {
        alert("❌ فشل عملية الموافقة: " + error);
        console.error("خطأ الترانزاكشن:", error);
    }
}
// ... (بقية دوال المشرف تحتاج لمنطق مشابه)